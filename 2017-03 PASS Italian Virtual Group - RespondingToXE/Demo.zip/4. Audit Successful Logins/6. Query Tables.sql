SELECT TOP(10) *
FROM TOOLS.dbo.AuditLogin_Staging
ORDER BY event_date DESC


SELECT *
FROM TOOLS.dbo.AuditLogin
