USE msdb;

DECLARE @collection_set_id int;

SELECT @collection_set_id = collection_set_id
FROM dbo.syscollector_collection_sets
WHERE name = 'Blocking and Deadlocking'

IF @@ROWCOUNT > 0
BEGIN
    EXEC dbo.sp_syscollector_stop_collection_set @collection_set_id;
END